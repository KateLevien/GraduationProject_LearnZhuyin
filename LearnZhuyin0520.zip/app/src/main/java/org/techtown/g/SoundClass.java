package org.techtown.g;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class SoundClass extends AppCompatActivity {

        // MediaPlayer
        MediaPlayer mediaPlayer;

        Button startButton;


        @Override
        protected void onCreate(Bundle savedInstanceState) {

            super.onCreate(savedInstanceState);
            setContentView(R.layout.fragment_home);

            startButton = findViewById(R.id.button_all);


            startButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // MediaPlayer 객체 할당
                    mediaPlayer = MediaPlayer.create(SoundClass.this, R.raw.b_er);
                    mediaPlayer.start();
                }
            });

    }
}
